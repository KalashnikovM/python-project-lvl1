from random import randint
import prompt


def main():
    """Run an example code."""
    # it is ok to have some magical numbers locally
    print('Welcome to the Brain Games!')
    checker()


if __name__ == '__main__':
    main()


def checker():
    i = 0
    while i <= 2:
        number = int(randint(1, 100))
        print('Question: ', number)
        answer = prompt.string('Your answer:')
        print(answer)
        if number % 2 == 1 and answer == 'no':
            i += 1
            print('Correct')
        elif number % 2 == 0 and answer == 'yes':
            i += 1
            print('Correct')
        else:
            print('Lets again')
            break
