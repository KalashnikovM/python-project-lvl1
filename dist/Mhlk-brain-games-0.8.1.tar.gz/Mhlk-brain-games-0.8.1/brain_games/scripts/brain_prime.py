from brain_games.engine import run_engine
from brain_games.games import prime


def main():
    run_engine(prime)


if __name__ == '__main__':
    main()
