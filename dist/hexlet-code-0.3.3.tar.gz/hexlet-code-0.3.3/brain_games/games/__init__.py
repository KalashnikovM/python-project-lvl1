# -*- coding:utf-8 -*-

"""Games examples."""